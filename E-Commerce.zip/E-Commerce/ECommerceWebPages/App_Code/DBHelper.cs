﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace E_Commerce.ECommerceWebPages.App_Code
{
    public static class DBHelper
    {
        private static string connStr = ConfigurationManager.ConnectionStrings["Test"].ToString();

        public static string ConnectionString { get; internal set; }

        public static DataTable GetData(string query, params SqlParameter[] parameters)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null) cmd.Parameters.AddRange(parameters);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }


        public static int ExecuteCommand(string query, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddRange(parameters);
                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }


        public static SqlParameter MakeParameter(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }


        public static object ExecuteScalar(string query, List<SqlParameter> parameters = null)
        {
            using (SqlConnection con = new SqlConnection(connStr))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                if (parameters != null && parameters.Count > 0)
                    cmd.Parameters.AddRange(parameters.ToArray());

                con.Open();
                return cmd.ExecuteScalar();
            }
        }


        public static DataTable GetDataTable(string query, SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null)
                        cmd.Parameters.AddRange(parameters);

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        internal static object ExecuteScalar(string insertOrder, SqlParameter[] orderParams)
        {
            throw new NotImplementedException();
        }

        public static int ExecuteQuery(string query, params SqlParameter[] parameters)
        {
            int affectedRows = 0;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null) cmd.Parameters.AddRange(parameters);
                    conn.Open();
                    affectedRows = cmd.ExecuteNonQuery();
                }
            }
            return affectedRows;
        }

        internal static object ExecuteScalar(string checkQuery, SqlParameter sqlParameter1, SqlParameter sqlParameter2)
        {
            throw new NotImplementedException();
        }

    }

}