﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_Commerce.ECommerceWebPages.App_Code
{
    public class SessionHelper
    {
        public static bool IsLoggedIn()
        {
            return HttpContext.Current.Session["UserId"] != null;
        }

        public static bool IsAdmin()
        {
            return HttpContext.Current.Session["Role"] != null &&
                   HttpContext.Current.Session["Role"].ToString() == "Admin";
        }

        public static bool IsCustomer()
        {
            return HttpContext.Current.Session["Role"] != null &&
                   HttpContext.Current.Session["Role"].ToString() == "Customer";
        }

    }
}