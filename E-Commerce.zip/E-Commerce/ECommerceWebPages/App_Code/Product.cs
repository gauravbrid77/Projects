﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_Commerce.ECommerceWebPages.App_Code
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string ImageUrl { get; set; }
        public string Category { get; set; }
        public int Stock { get; set; }

        public Product() { }

        public Product(int productId, string productName, string desc, decimal price, string imgUrl, string category, int stock)
        {
            ProductId = productId;
            ProductName = productName;
            Description = desc;
            Price = price;
            ImageUrl = imgUrl;
            Category = category;
            Stock = stock;
        }
    }

}