﻿namespace E_Commerce.ECommerceWebPages.App_Code
{
    internal class Parameters
    {
    }
}