﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_Commerce.ECommerceWebPages.App_Code
{
    public class User
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Password { get; set; }
        public string Role { get; }

        public User() { }

        public User(int userId, string fullName, string email, string password, string role)
        {
            UserId = userId;
            FullName = fullName;
            Email = email;
            Password = password;
            Role = role;
        }
    }

}