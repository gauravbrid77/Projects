﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Profile : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["Test"].ToString();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] == null)
            {
                pnlNotLoggedIn.Visible = true;
                pnlProfile.Visible = false;
                return;
            }

            if (!IsPostBack)
            {
                LoadProfile();
            }
        }

        private void LoadProfile()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT FullName, Email, Mobile FROM BharatStore_Users WHERE UserId=@UserId";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserId", Session["UserId"]);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtFullName.Text = reader["FullName"].ToString();
                    txtEmail.Text = reader["Email"].ToString();
                    txtMobile.Text = reader["Mobile"].ToString();
                    pnlProfile.Visible = true;
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "UPDATE BharatStore_Users SET FullName=@FullName, Mobile=@Mobile WHERE UserId=@UserId";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@FullName", txtFullName.Text.Trim());
                cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
                cmd.Parameters.AddWithValue("@UserId", Session["UserId"]);

                conn.Open();
                int rows = cmd.ExecuteNonQuery();

                lblMessage.Text = rows > 0 ? "Profile updated successfully!" : "Error updating profile.";
                lblMessage.CssClass = rows > 0 ? "text-success" : "text-danger";
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();

            // Redirect with message
            Response.Redirect("Home.aspx?message=logout");

        }
    }
}
