﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class ProductDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] != null)
                {
                    int productId = Convert.ToInt32(Request.QueryString["id"]);
                    LoadProductDetails(productId);
                }
                else
                {
                    Response.Redirect("Products.aspx"); // if no id found, redirect back
                }
            }
        }

        private void LoadProductDetails(int productId)
        {
            string connStr = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT * FROM BharatStore_Products WHERE ProductId = @ProductId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ProductId", productId);

                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        lblProductName.Text = dr["ProductName"].ToString();
                        lblDescription.Text = dr["Description"].ToString();
                        lblPrice.Text = dr["Price"].ToString();
                        lblCategory.Text = dr["Category"].ToString();
                        lblStock.Text = dr["Stock"].ToString();
                        imgProduct.ImageUrl = dr["ImageUrl"].ToString();
                    }
                }
            }
        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            // ✅ Add to cart logic (Session-based for now)
            // For example: Session["Cart"] = some list of products
            Response.Write("<script>alert('Product added to cart!');</script>");
        }
    }
}
