﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Cart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCart();
            }
        }

        private void LoadCart()
        {
            DataTable cart = Session["Cart"] as DataTable;
            if (cart != null && cart.Rows.Count > 0)
            {
                gvCart.DataSource = cart;
                gvCart.DataBind();
                pnlCart.Visible = true;
                pnlEmpty.Visible = false;

                decimal total = cart.AsEnumerable().Sum(r => Convert.ToDecimal(r["Price"]) * Convert.ToInt32(r["Quantity"]));
                lblTotal.Text = "Total: ₹ " + total.ToString("N2");
            }
            else
            {
                pnlCart.Visible = false;
                pnlEmpty.Visible = true;
            }
        }

        protected void gvCart_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DataTable cart = Session["Cart"] as DataTable;
            if (cart == null) return;

            int productId = Convert.ToInt32(e.CommandArgument);
            DataRow row = cart.Rows.Cast<DataRow>().FirstOrDefault(r => Convert.ToInt32(r["ProductId"]) == productId);
            if (row == null) return;

            if (e.CommandName == "UpdateQty")
            {
                GridViewRow gvr = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                TextBox txtQty = (TextBox)gvr.FindControl("txtQty");

                if (int.TryParse(txtQty.Text, out int newQty) && newQty > 0)
                {
                    row["Quantity"] = newQty;
                }
            }
            else if (e.CommandName == "Remove")
            {
                cart.Rows.Remove(row);
            }

            Session["Cart"] = cart;
            LoadCart();
        }

    }
}
