﻿using E_Commerce.ECommerceWebPages.App_Code;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Checkout : Page
    {
        private DataTable cart;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    cart = Session["Cart"] as DataTable;
                    BindCart();
                }
                else
                {
                    // Re-assign cart on postback for button click
                    cart = Session["Cart"] as DataTable;
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error loading cart. Check debug for details.";
                System.Diagnostics.Debug.WriteLine("Page_Load Error: " + ex.ToString());
            }
        }

        private void BindCart()
        {
            try
            {
                if (cart != null && cart.Rows.Count > 0)
                {
                    if (!cart.Columns.Contains("Total"))
                        cart.Columns.Add("Total", typeof(decimal));

                    decimal grandTotal = 0;

                    foreach (DataRow row in cart.Rows)
                    {
                        int quantity = 0;
                        decimal price = 0;

                        int.TryParse(row["Quantity"]?.ToString(), out quantity);
                        decimal.TryParse(row["Price"]?.ToString(), out price);

                        row["Total"] = quantity * price;
                        grandTotal += quantity * price;
                    }

                    gvCart.DataSource = cart;
                    gvCart.DataBind();

                    lblGrandTotal.Text = "₹ " + grandTotal.ToString("0.00");
                    gvCart.Visible = true;
                    btnPlaceOrder.Enabled = true;
                    lblMessage.Text = "";
                }
                else
                {
                    lblMessage.Text = "Your cart is empty.";
                    gvCart.Visible = false;
                    btnPlaceOrder.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error binding cart. Check debug for details.";
                System.Diagnostics.Debug.WriteLine("BindCart Error: " + ex.ToString());
            }
        }

        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            SqlTransaction tx = null;
            try
            {
                // Always re-fetch cart on postback
                cart = Session["Cart"] as DataTable;

                // 1) Basic validations
                if (Session["UserID"] == null)
                {
                    lblMessage.Text = "Please log in to place an order.";
                    return;
                }
                if (cart == null || cart.Rows.Count == 0)
                {
                    lblMessage.Text = "Your cart is empty.";
                    return;
                }

                string name = txtName.Text.Trim();
                string address = txtAddress.Text.Trim();
                string phone = txtPhone.Text.Trim();
                string email = txtEmail.Text.Trim();

                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(address) ||
                    string.IsNullOrWhiteSpace(phone) || string.IsNullOrWhiteSpace(email))
                {
                    lblMessage.Text = "All fields are required.";
                    return;
                }

                if (Session["UserId"] == null) // lowercase "d" to match your login
                {
                    lblMessage.Text = "Please log in to place an order.";
                    return;
                }

                int userId = Convert.ToInt32(Session["UserId"]);


                // 2) Ensure cart has a Total column and compute grand total
                if (!cart.Columns.Contains("Total"))
                    cart.Columns.Add("Total", typeof(decimal));

                decimal grandTotal = 0m;
                foreach (DataRow row in cart.Rows)
                {
                    int qty = 0;
                    decimal price = 0m;

                    int.TryParse(row["Quantity"]?.ToString(), out qty);
                    decimal.TryParse(row["Price"]?.ToString(), out price);

                    if (qty <= 0) throw new InvalidOperationException("Invalid quantity in cart item.");
                    if (price < 0) throw new InvalidOperationException("Invalid price in cart item.");

                    decimal total = qty * price;
                    row["Total"] = total;
                    grandTotal += total;
                }

                // 3) Open connection and begin transaction
                string cs = ConfigurationManager.ConnectionStrings["Test"]?.ConnectionString;
                if (string.IsNullOrWhiteSpace(cs))
                {
                    lblMessage.Text = "Database connection is not configured.";
                    return;
                }

                using (SqlConnection conn = new SqlConnection(cs))
                {
                    conn.Open();
                    tx = conn.BeginTransaction("PlaceOrderTx");

                    // 4) Insert Order (header)
                    int orderId;
                    using (SqlCommand cmd = new SqlCommand(@"
                INSERT INTO BharatStore_Orders 
                    (UserID, CustomerName, Address, Phone, Email, GrandTotal) 
                OUTPUT INSERTED.OrderID
                VALUES (@UserID, @CustomerName, @Address, @Phone, @Email, @GrandTotal);
            ", conn, tx))
                    {
                        cmd.Parameters.Add("@UserID", System.Data.SqlDbType.Int).Value = userId;
                        cmd.Parameters.Add("@CustomerName", System.Data.SqlDbType.NVarChar, 100).Value = name;
                        cmd.Parameters.Add("@Address", System.Data.SqlDbType.NVarChar, 200).Value = address;
                        cmd.Parameters.Add("@Phone", System.Data.SqlDbType.NVarChar, 20).Value = phone;
                        cmd.Parameters.Add("@Email", System.Data.SqlDbType.NVarChar, 100).Value = email;
                        cmd.Parameters.Add("@GrandTotal", System.Data.SqlDbType.Decimal).Value = grandTotal;
                        cmd.Parameters["@GrandTotal"].Precision = 18; // match DECIMAL(18,2)
                        cmd.Parameters["@GrandTotal"].Scale = 2;

                        object scalar = cmd.ExecuteScalar();
                        if (scalar == null) throw new Exception("Failed to create order header.");
                        orderId = Convert.ToInt32(scalar);
                    }

                    // 5) Insert Order Details (lines)
                    using (SqlCommand cmd = new SqlCommand(@"
                INSERT INTO BharatStore_OrderDetails
                    (OrderID, ProductID, ProductName, Quantity, Price, Total)
                VALUES
                    (@OrderID, @ProductID, @ProductName, @Quantity, @Price, @Total);
            ", conn, tx))
                    {
                        // Pre-create parameters for performance
                        cmd.Parameters.Add("@OrderID", System.Data.SqlDbType.Int);
                        cmd.Parameters.Add("@ProductID", System.Data.SqlDbType.Int);
                        cmd.Parameters.Add("@ProductName", System.Data.SqlDbType.NVarChar, 200);
                        cmd.Parameters.Add("@Quantity", System.Data.SqlDbType.Int);
                        var pPrice = cmd.Parameters.Add("@Price", System.Data.SqlDbType.Decimal);
                        pPrice.Precision = 18; pPrice.Scale = 2;
                        var pTotal = cmd.Parameters.Add("@Total", System.Data.SqlDbType.Decimal);
                        pTotal.Precision = 18; pTotal.Scale = 2;

                        foreach (DataRow row in cart.Rows)
                        {
                            int productId = 0, qty = 0;
                            decimal price = 0m, total = 0m;

                            if (!int.TryParse(row["ProductID"]?.ToString(), out productId) || productId <= 0)
                                throw new InvalidOperationException("Invalid ProductID in cart.");
                            int.TryParse(row["Quantity"]?.ToString(), out qty);
                            decimal.TryParse(row["Price"]?.ToString(), out price);
                            decimal.TryParse(row["Total"]?.ToString(), out total);

                            cmd.Parameters["@OrderID"].Value = orderId;
                            cmd.Parameters["@ProductID"].Value = productId;
                            cmd.Parameters["@ProductName"].Value = (row["ProductName"] ?? "").ToString();
                            cmd.Parameters["@Quantity"].Value = qty;
                            cmd.Parameters["@Price"].Value = price;
                            cmd.Parameters["@Total"].Value = total;

                            cmd.ExecuteNonQuery();
                        }
                    }

                    // 6) Commit and redirect
                    tx.Commit();
                    Session["Cart"] = null;
                    Response.Redirect("OrderConfirmation.aspx?OrderID=" + orderId, false);
                    Context.ApplicationInstance.CompleteRequest(); // avoid ThreadAbort
                }
            }
            catch (SqlException ex)
            {
                try { tx?.Rollback(); } catch { /* ignore rollback errors */ }
                lblMessage.Text = "Database error while placing order.";
                System.Diagnostics.Debug.WriteLine("SQL Exception: " + ex);
            }
            catch (Exception ex)
            {
                try { tx?.Rollback(); } catch { /* ignore rollback errors */ }
                lblMessage.Text = "Unexpected error while placing order.";
                System.Diagnostics.Debug.WriteLine("General Exception: " + ex);
            }
        }


    }
}