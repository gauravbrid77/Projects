﻿using E_Commerce.ECommerceWebPages.App_Code;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace E_Commerce.ECommerceWebPages
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCategories();
                LoadFilteredProducts();
            }
        }

        private void LoadCategories()
        {
            string query = "SELECT DISTINCT Category FROM BharatStore_Products WHERE IsActive = 1";
            DataTable dt = DBHelper.GetData(query);
            ddlCategory.Items.Clear();
            ddlCategory.Items.Add("All");
            foreach (DataRow row in dt.Rows)
            {
                ddlCategory.Items.Add(row["Category"].ToString());
            }
        }

        private void LoadFilteredProducts()
        {
            string query = @"SELECT ProductId, ProductName, Description, Price, ImageUrl 
                             FROM BharatStore_Products 
                             WHERE IsActive = 1
                               AND (@Category IS NULL OR Category = @Category)
                               AND (@MinPrice IS NULL OR Price >= @MinPrice)
                               AND (@MaxPrice IS NULL OR Price <= @MaxPrice)
                               AND (@Search IS NULL OR ProductName LIKE '%' + @Search + '%' OR Description LIKE '%' + @Search + '%')";

            var parameters = new[]
            {
                DBHelper.MakeParameter("@Category", ddlCategory.SelectedValue == "All" ? (object)DBNull.Value : ddlCategory.SelectedValue),
                DBHelper.MakeParameter("@MinPrice", string.IsNullOrEmpty(txtMinPrice.Text) ? (object)DBNull.Value : Convert.ToDecimal(txtMinPrice.Text)),
                DBHelper.MakeParameter("@MaxPrice", string.IsNullOrEmpty(txtMaxPrice.Text) ? (object)DBNull.Value : Convert.ToDecimal(txtMaxPrice.Text)),
                DBHelper.MakeParameter("@Search", string.IsNullOrEmpty(txtSearch.Text) ? (object)DBNull.Value : txtSearch.Text.Trim())
            };

            DataTable dt = DBHelper.GetData(query, parameters);
            rptProducts.DataSource = dt;
            rptProducts.DataBind();
        }

        protected void btnFilter_Click(object sender, EventArgs e)
        {
            LoadFilteredProducts();
        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            var btn = (System.Web.UI.WebControls.Button)sender;
            int productId = Convert.ToInt32(btn.CommandArgument);

            DataTable dtProduct = DBHelper.GetData("SELECT * FROM BharatStore_Products WHERE ProductId = @ProductId",
                DBHelper.MakeParameter("@ProductId", productId));

            if (Session["Cart"] == null)
            {
                DataTable cart = dtProduct.Clone();
                cart.ImportRow(dtProduct.Rows[0]);
                Session["Cart"] = cart;
            }
            else
            {
                DataTable cart = (DataTable)Session["Cart"];
                cart.ImportRow(dtProduct.Rows[0]);
                Session["Cart"] = cart;
            }
        }

        protected void btnBuyNow_Click(object sender, EventArgs e)
        {
            btnAddToCart_Click(sender, e);
            Response.Redirect("Cart.aspx");
        }

        protected void rptFeatured_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            int productId = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "AddToCart" || e.CommandName == "BuyNow")
            {
                DataTable cart;

                // If cart doesn't exist, create new
                if (Session["Cart"] == null)
                {
                    cart = new DataTable();
                    cart.Columns.Add("ProductId", typeof(int));
                    cart.Columns.Add("ProductName", typeof(string));
                    cart.Columns.Add("Price", typeof(decimal));
                    cart.Columns.Add("Quantity", typeof(int));
                }
                else
                {
                    cart = (DataTable)Session["Cart"];
                }

                // Get product details
                string connStr = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string query = @"SELECT ProductId, ProductName, Price 
                                     FROM BharatStore_Products 
                                     WHERE ProductId = @ProductId";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ProductId", productId);
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            // Check if product already in cart
                            DataRow existingRow = cart.Rows
                                .Cast<DataRow>()
                                .FirstOrDefault(r => (int)r["ProductId"] == productId);

                            if (existingRow != null)
                            {
                                existingRow["Quantity"] = (int)existingRow["Quantity"] + 1;
                            }
                            else
                            {
                                cart.Rows.Add(reader["ProductId"], reader["ProductName"], reader["Price"], 1);
                            }
                        }
                    }
                }

                // Save updated cart to Session
                Session["Cart"] = cart;

                // Redirect to cart page if Buy Now clicked
                if (e.CommandName == "BuyNow")
                {
                    Response.Redirect("Cart.aspx");
                }
            }
        }
    }
}
