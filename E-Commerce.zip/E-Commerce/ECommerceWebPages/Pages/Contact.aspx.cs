﻿using System;
using System.Net.Mail;
using System.Xml.Linq;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Example: Send email (SMTP settings must be configured in Web.config)
                MailMessage mail = new MailMessage();
                mail.To.Add("support@bharatstore.com");
                mail.From = new MailAddress(txtEmail.Text);
                mail.Subject = "Contact Form Submission from " + txtName.Text;
                mail.Body = txtMessage.Text;

                SmtpClient smtp = new SmtpClient();
                smtp.Send(mail);

                lblResult.Text = "Thank you! Your message has been sent.";
            }
            catch (Exception ex)
            {
                lblResult.CssClass = "mt-3 d-block text-danger";
                lblResult.Text = "Error sending message: " + ex.Message;
            }
        }
    }
}
