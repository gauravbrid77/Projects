﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Check if user logged in
                if (Session["FullName"] == null || Session["Role"] == null)
                {
                    Response.Redirect("Login.aspx");
                    return;
                }

                // Check role
                if (Session["Role"].ToString() != "Admin")
                {
                    Response.Redirect("Unauthorized.aspx"); // create this page or redirect to Home.aspx
                    return;
                }

                // Show logged-in user name
                lblUserName.Text = Session["FullName"].ToString();

                // Show success message once
                if (Session["SuccessMessage"] != null)
                {
                    lblMessage.Text = Session["SuccessMessage"].ToString();
                    lblMessage.Visible = true;
                    Session["SuccessMessage"] = null;
                }

                LoadDashboardData();
            }
        }

        private void LoadDashboardData()
        {
            string connStr = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Get total products
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM BharatStore_Products WHERE IsActive=1", conn))
                {
                    lblTotalProducts.Text = cmd.ExecuteScalar().ToString();
                }

                // Get total orders
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM BharatStore_Orders", conn))
                {
                    lblTotalOrders.Text = cmd.ExecuteScalar().ToString();
                }

                // Get total customers
                using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM BharatStore_Users WHERE Role='Customer'", conn))
                {
                    lblTotalCustomers.Text = cmd.ExecuteScalar().ToString();
                }

                // Recent products
                using (SqlCommand cmd = new SqlCommand("SELECT TOP 5 ProductId, ProductName, Price, Stock FROM BharatStore_Products ORDER BY ProductId DESC", conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    gvRecentProducts.DataSource = dt;
                    gvRecentProducts.DataBind();
                }
            }
        }
    }
}
