﻿using System;
using System.Data;
using System.Data.SqlClient;
using E_Commerce.ECommerceWebPages.App_Code;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        protected void btnChangePassword_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string oldPassword = txtOldPassword.Text.Trim();
            string newPassword = txtNewPassword.Text.Trim();
            string confirmPassword = txtConfirmPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(oldPassword) ||
                string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
            {
                lblMessage.Text = "All fields are required!";
                return;
            }

            if (newPassword != confirmPassword)
            {
                lblMessage.Text = "New Password and Confirm Password do not match!";
                return;
            }

            // Check if old password is correct
            DataTable dtUser = DBHelper.GetData(
                "SELECT * FROM BharatStore_Users WHERE Username=@Username AND Password=@Password",
                DBHelper.MakeParameter("@Username", username),
                DBHelper.MakeParameter("@Password", oldPassword)
            );

            if (dtUser.Rows.Count > 0)
            {
                // Update password
                int rows = DBHelper.ExecuteQuery(
                    "UPDATE BharatStore_Users SET Password=@Password WHERE Username=@Username",
                    DBHelper.MakeParameter("@Password", newPassword),
                    DBHelper.MakeParameter("@Username", username)
                );

                if (rows > 0)
                {
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Password changed successfully!";
                    txtOldPassword.Text = txtNewPassword.Text = txtConfirmPassword.Text = "";
                }
                else
                {
                    lblMessage.Text = "Error updating password. Try again!";
                }
            }
            else
            {
                lblMessage.Text = "Invalid username or old password!";
            }
        }
    }
}
