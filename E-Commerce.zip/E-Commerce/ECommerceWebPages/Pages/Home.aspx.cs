﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string message = Request.QueryString["message"];

                if (!string.IsNullOrEmpty(message))
                {
                    if (message == "login")
                    {
                        lblMessage.Text = "✅ You have successfully logged in!";
                        lblMessage.Visible = true;
                    }
                    else if (message == "logout")
                    {
                        lblMessage.Text = "✅ You have successfully logged out!";
                        lblMessage.Visible = true;
                    }
                }

                // Toggle overlay class based on login status
                overlayClass.Value = Session["UserId"] != null ? "overlay-light" : "overlay-dark";

                LoadFeaturedProducts();

                int cartCount = GetCartCountFromDB();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "updateCartCount",
                    $"document.getElementById('cartCount').innerText = '{cartCount}';", true);
            }
        }

        private void LoadFeaturedProducts()
        {
            string connStr = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = @"SELECT TOP 40 ProductId, ProductName, Description, Price, ImageUrl 
                                 FROM BharatStore_Products 
                                 WHERE IsActive = 1 
                                 ORDER BY NEWID()"; // Random products

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            rptFeatured.DataSource = reader;
                            rptFeatured.DataBind();
                            pnlNoProducts.Visible = false;
                        }
                        else
                        {
                            rptFeatured.DataSource = null;
                            rptFeatured.DataBind();
                            pnlNoProducts.Visible = true;
                        }
                    }
                }
            }
        }

        protected void rptFeatured_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            int productId = Convert.ToInt32(e.CommandArgument); 

            if (e.CommandName == "AddToCart" || e.CommandName == "BuyNow")
            {
                DataTable cart;

                // If cart doesn't exist, create new
                if (Session["Cart"] == null)
                {
                    cart = new DataTable();
                    cart.Columns.Add("ProductId", typeof(int));
                    cart.Columns.Add("ProductName", typeof(string));
                    cart.Columns.Add("Price", typeof(decimal));
                    cart.Columns.Add("Quantity", typeof(int));
                }
                else
                {
                    cart = (DataTable)Session["Cart"];
                }

                // Get product details
                string connStr = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string query = @"SELECT ProductId, ProductName, Price 
                                     FROM BharatStore_Products 
                                     WHERE ProductId = @ProductId";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ProductId", productId);
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            // Check if product already in cart
                            DataRow existingRow = cart.Rows
                                .Cast<DataRow>()
                                .FirstOrDefault(r => (int)r["ProductId"] == productId);

                            if (existingRow != null)
                            {
                                existingRow["Quantity"] = (int)existingRow["Quantity"] + 1;
                            }
                            else
                            {
                                cart.Rows.Add(reader["ProductId"], reader["ProductName"], reader["Price"], 1);
                            }
                        }
                    }
                }

                // Save updated cart to Session
                Session["Cart"] = cart;

                // Redirect to cart page if Buy Now clicked
                if (e.CommandName == "BuyNow")
                {
                    Response.Redirect("Cart.aspx");
                }
            }
        }

        private int GetCartCountFromDB()
        {
            if (Session["UserID"] == null) return 0;

            int userId = Convert.ToInt32(Session["UserID"]);
            int count = 0;

            string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["Test"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT SUM(Quantity) FROM BharatStore_Cart WHERE UserID=@UserID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    conn.Open();
                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value && result != null)
                        count = Convert.ToInt32(result);
                }
            }

            return count;
        }

        [WebMethod]
        public static int GetCartCount()
        {
            if (HttpContext.Current.Session["Cart"] == null)
                return 0;

            DataTable cart = HttpContext.Current.Session["Cart"] as DataTable;
            int count = cart.AsEnumerable().Sum(r => Convert.ToInt32(r["Quantity"]));
            return count;
        }
    }
}
