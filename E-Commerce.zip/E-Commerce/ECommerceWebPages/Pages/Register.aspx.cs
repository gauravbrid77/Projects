﻿using E_Commerce.ECommerceWebPages.App_Code;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string mobile = txtMobile.Text.Trim();
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;

            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(mobile) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
            {
                lblMessage.Text = "All fields are required.";
                return;
            }

            if (password != confirmPassword)
            {
                lblMessage.Text = "Passwords do not match.";
                return;
            }

            // Check if Email or Mobile already exists
            string checkQuery = "SELECT COUNT(*) FROM BharatStore_Users WHERE Email = @Email OR Mobile = @Mobile";
            var parameters = new List<System.Data.SqlClient.SqlParameter>
            {
                DBHelper.MakeParameter("@Email", email),
                DBHelper.MakeParameter("@Mobile", mobile)
            };

            var result = DBHelper.ExecuteScalar(checkQuery, parameters);

            if (Convert.ToInt32(result) > 0)
            {
                lblMessage.Text = "Email or Mobile number is already registered.";
                return;
            }

            // Insert new user with default Role = Customer
            string insertQuery = "INSERT INTO BharatStore_Users (FullName, Email, Mobile, Password, Role) " +
                                 "VALUES (@FullName, @Email, @Mobile, @Password, 'Customer')";

            var insertParams = new[]
            {
                DBHelper.MakeParameter("@FullName", fullName),
                DBHelper.MakeParameter("@Email", email),
                DBHelper.MakeParameter("@Mobile", mobile),
                DBHelper.MakeParameter("@Password", password)
            };

            try
            {
                DBHelper.ExecuteCommand(insertQuery, insertParams);
                lblMessage.CssClass = "text-success fw-bold";
                lblMessage.Text = "Registration successful. You can now log in.";
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error: " + ex.Message;
            }
        }
    }
}
