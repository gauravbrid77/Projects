﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class OrderConfirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["OrderID"] != null)
                {
                    int orderId = Convert.ToInt32(Request.QueryString["OrderID"]);
                    LoadOrderDetails(orderId);
                }
                else
                {
                    Response.Redirect("Default.aspx");
                }
            }
        }

        private void LoadOrderDetails(int orderId)
        {
            string cs = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                // Get Order Info
                SqlCommand cmdOrder = new SqlCommand("SELECT * FROM BharatStore_Orders WHERE OrderID=@OrderID", con);
                cmdOrder.Parameters.AddWithValue("@OrderID", orderId);
                SqlDataReader dr = cmdOrder.ExecuteReader();

                if (dr.Read())
                {
                    lblOrderID.Text = dr["OrderID"].ToString();
                    lblCustomerName.Text = dr["CustomerName"].ToString();
                    lblOrderDate.Text = Convert.ToDateTime(dr["OrderDate"]).ToString("dd-MMM-yyyy");
                    lblStatus.Text = dr["OrderStatus"].ToString();
                    lblAddress.Text = dr["Address"].ToString();
                    lblGrandTotal.Text = Convert.ToDecimal(dr["GrandTotal"]).ToString("C");
                }
                dr.Close();

                // Get Order Items
                SqlCommand cmdItems = new SqlCommand("SELECT ProductName, Quantity, Price, Total FROM BharatStore_OrderDetails WHERE OrderID=@OrderID", con);
                cmdItems.Parameters.AddWithValue("@OrderID", orderId);

                SqlDataAdapter da = new SqlDataAdapter(cmdItems);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvOrderItems.DataSource = dt;
                gvOrderItems.DataBind();
            }
        }
    }
}
