﻿using E_Commerce.ECommerceWebPages.App_Code;
using E_Commerce.ECommerceWebPages.Pages;
using System;
using System.Data;
using System.Xml.Linq;

namespace E_Commerce.ECommerceWebPages.Pages.Admin
{
    public partial class ManageProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserRole"]?.ToString() != "Admin")
                Response.Redirect("~/Pages/Login.aspx");

            if (!IsPostBack)
                LoadProducts();
        }

        private void LoadProducts()
        {
            string query = "SELECT * FROM BharatStore_Products ORDER BY ProductId DESC";
            gvProducts.DataSource = DBHelper.GetData(query);
            gvProducts.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string productName = txtProductName.Text.Trim();
            string category = txtCategory.Text.Trim();
            string description = txtDescription.Text.Trim();
            string price = txtPrice.Text.Trim();
            string imageUrl = txtImageUrl.Text.Trim();
            string stock = txtStock.Text.Trim();
            bool isActive = chkIsActive.Checked;

            if (string.IsNullOrEmpty(productName) || string.IsNullOrEmpty(price))
                return;

            string query;
            if (string.IsNullOrEmpty(hfProductId.Value))
            {
                // Insert
                query = $@"
                    INSERT INTO BharatStore_Products
                    (ProductName, Description, Price, ImageUrl, Category, Stock, IsActive)
                    VALUES
                    ('{productName}', '{description}', {price}, '{imageUrl}', '{category}', {stock}, {(isActive ? 1 : 0)})
                ";
            }
            else
            {
                // Update
                query = $@"
                    UPDATE BharatStore_Products SET
                    ProductName = '{productName}',
                    Description = '{description}',
                    Price = {price},
                    ImageUrl = '{imageUrl}',
                    Category = '{category}',
                    Stock = {stock},
                    IsActive = {(isActive ? 1 : 0)}
                    WHERE ProductId = {hfProductId.Value}
                ";
            }

            DBHelper.ExecuteCommand(query);
            ClearForm();
            LoadProducts();
        }

        protected void gvProducts_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditProduct")
            {
                string id = e.CommandArgument.ToString();
                string query = $"SELECT * FROM BharatStore_Products WHERE ProductId = {id}";
                DataTable dt = DBHelper.GetData(query);
                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    hfProductId.Value = row["ProductId"].ToString();
                    txtProductName.Text = row["ProductName"].ToString();
                    txtDescription.Text = row["Description"].ToString();
                    txtPrice.Text = row["Price"].ToString();
                    txtImageUrl.Text = row["ImageUrl"].ToString();
                    txtCategory.Text = row["Category"].ToString();
                    txtStock.Text = row["Stock"].ToString();
                    chkIsActive.Checked = Convert.ToBoolean(row["IsActive"]);
                }
            }
            else if (e.CommandName == "DeleteProduct")
            {
                string id = e.CommandArgument.ToString();
                string query = $"DELETE FROM BharatStore_Products WHERE ProductId = {id}";
                DBHelper.ExecuteCommand(query);
                LoadProducts();
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            hfProductId.Value = "";
            txtProductName.Text = txtDescription.Text = txtPrice.Text = txtImageUrl.Text = txtCategory.Text = txtStock.Text = "";
            chkIsActive.Checked = true;
        }
    }
}
