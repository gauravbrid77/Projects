﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

namespace E_Commerce.ECommerceWebPages.Pages.Admin 
{
    public partial class ManageOrders : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            // ✅ Only Admins allowed
            if (Session["Role"] == null || Session["Role"].ToString() != "Admin")
            {
                Response.Redirect("Home.aspx"); // Redirect non-admins
                return;
            }

            if (!IsPostBack)
            {
                BindOrders();
            }
        }


        private void BindOrders()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT OrderID, CustomerName, OrderDate, GrandTotal, OrderStatus FROM BharatStore_Orders ORDER BY OrderDate ASC", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gvOrders.DataSource = dt;
                gvOrders.DataBind();
            }
        }

        protected void gvOrders_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvOrders.EditIndex = e.NewEditIndex;
            BindOrders();

            // After rebind, we can find current status from the bound column
            string currentStatus = gvOrders.Rows[e.NewEditIndex].Cells[4].Text; // column index of Status
            DropDownList ddl = (DropDownList)gvOrders.Rows[e.NewEditIndex].FindControl("ddlStatus");

            if (!string.IsNullOrEmpty(currentStatus) && ddl.Items.FindByText(currentStatus) != null)
            {
                ddl.SelectedValue = currentStatus;
            }
        }


        protected void gvOrders_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int orderId = Convert.ToInt32(gvOrders.DataKeys[e.RowIndex].Value);
            DropDownList ddl = (DropDownList)gvOrders.Rows[e.RowIndex].FindControl("ddlStatus");
            string newStatus = ddl.SelectedValue;

            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("UPDATE BharatStore_Orders SET OrderStatus=@Status WHERE OrderID=@OrderID", con);
                cmd.Parameters.AddWithValue("@Status", newStatus);
                cmd.Parameters.AddWithValue("@OrderID", orderId);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            gvOrders.EditIndex = -1;
            BindOrders();
        }


        protected void gvOrders_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvOrders.EditIndex = -1;
            BindOrders();
        }
    }
}
