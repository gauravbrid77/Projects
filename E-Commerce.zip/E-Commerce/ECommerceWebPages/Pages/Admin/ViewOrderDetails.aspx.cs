﻿using E_Commerce.ECommerceWebPages.App_Code;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace E_Commerce.ECommerceWebPages.Pages.Admin
{
    public partial class ViewOrderDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["orderId"] != null)
                {
                    int orderId = Convert.ToInt32(Request.QueryString["orderId"]);
                    LoadOrderDetails(orderId);
                }
                else
                {
                    Response.Redirect("Products.aspx");
                }
            }
        }


        private void LoadOrderDetails(int orderId)
        {
            string cs = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                // Load order information
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.BharatStore_Orders WHERE OrderID=@OrderID", con))
                {
                    cmd.Parameters.AddWithValue("@OrderID", orderId);
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        lblOrderID.Text = "Order ID: " + dr["OrderID"].ToString();
                        lblCustomerName.Text = "Customer: " + dr["CustomerName"].ToString();
                        lblAddress.Text = "Address: " + dr["Address"].ToString();
                        lblPhone.Text = "Phone: " + dr["Phone"].ToString();
                        lblEmail.Text = "Email: " + dr["Email"].ToString();
                        lblOrderDate.Text = "Order Date: " + Convert.ToDateTime(dr["OrderDate"]).ToString("dd-MMM-yyyy");
                        lblGrandTotal.Text = "Grand Total: ₹ " + dr["GrandTotal"].ToString();
                    }
                    dr.Close();
                }

                // Load order items
                using (SqlCommand cmd = new SqlCommand("SELECT ProductName, Quantity, Price, Total FROM dbo.BharatStore_OrderDetails WHERE OrderID=@OrderID", con))
                {
                    cmd.Parameters.AddWithValue("@OrderID", orderId);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    gvOrderItems.DataSource = dt;
                    gvOrderItems.DataBind();
                }
            }
        }
    }
}
