﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace E_Commerce.ECommerceWebPages.Pages.Admin
{
    public partial class AddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddProduct_Click(object sender, EventArgs e)
        {
            string productName = txtProductName.Text.Trim();
            string description = txtDescription.Text.Trim();
            decimal price = Convert.ToDecimal(txtPrice.Text.Trim());
            string imageUrl = txtImageUrl.Text.Trim();
            string category = txtCategory.Text.Trim();
            int stock = Convert.ToInt32(txtStock.Text.Trim());
            bool isActive = chkIsActive.Checked;

            string connStr = ConfigurationManager.ConnectionStrings["Test"].ToString();
            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = @"INSERT INTO BharatStore_Products 
                                (ProductName, Description, Price, ImageUrl, Category, Stock, IsActive)
                                VALUES 
                                (@ProductName, @Description, @Price, @ImageUrl, @Category, @Stock, @IsActive)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ProductName", productName);
                cmd.Parameters.AddWithValue("@Description", description);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@ImageUrl", imageUrl);
                cmd.Parameters.AddWithValue("@Category", category);
                cmd.Parameters.AddWithValue("@Stock", stock);
                cmd.Parameters.AddWithValue("@IsActive", isActive);

                con.Open();
                cmd.ExecuteNonQuery();
                lblMessage.Text = "Product added successfully!";
                ClearForm();
            }
        }

        private void ClearForm()
        {
            txtProductName.Text = "";
            txtDescription.Text = "";
            txtPrice.Text = "";
            txtImageUrl.Text = "";
            txtCategory.Text = "";
            txtStock.Text = "";
            chkIsActive.Checked = true;
        }
    }
}
