﻿using E_Commerce.ECommerceWebPages.App_Code;
using System;
using System.Configuration;
using System.Data.SqlClient;

namespace E_Commerce.ECommerceWebPages.Pages
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // ✅ Show success messages if available (like after logout)
                if (Session["SuccessMessage"] != null)
                {
                    lblMessage.Text = Session["SuccessMessage"].ToString();
                    lblMessage.Visible = true;
                    Session.Remove("SuccessMessage");
                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            string connStr = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                // Select only needed columns (more efficient)
                string query = @"SELECT UserId, FullName, Role 
                                 FROM BharatStore_Users 
                                 WHERE Email = @Email AND Password = @Password";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Password", password); // ⚠️ should be hashed in production

                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Read();

                        // Save user details in session
                        Session["UserId"] = dr["UserId"].ToString();
                        Session["FullName"] = dr["FullName"].ToString();
                        Session["Role"] = dr["Role"].ToString();

                        // Redirect based on role
                        if (Session["Role"].ToString() == "Admin")
                        {
                            Response.Redirect("Home.aspx?message=login");
                        }
                        else
                        {
                            Response.Redirect("Home.aspx?message=login");
                        }

                    }
                    else
                    {
                        lblMessage.Text = "Invalid email or password.";
                        lblMessage.Visible = true;
                    }
                }
            }
        }
    }
}
