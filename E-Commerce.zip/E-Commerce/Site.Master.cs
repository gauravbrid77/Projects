﻿using System;
using System.Web;
using System.Web.Security;

namespace E_Commerce
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Hide by default
                lnkManageOrders.Visible = false;

                // Show only if Admin is logged in
                if (Session["Role"] != null && Session["Role"].ToString() == "Admin")
                {
                    lnkManageOrders.Visible = true;
                }
            }
        }


        protected void lnkLogout_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Response.Redirect("~/Login.aspx");
        }
    }
}
